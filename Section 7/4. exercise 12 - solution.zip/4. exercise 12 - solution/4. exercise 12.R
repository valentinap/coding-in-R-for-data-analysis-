# 1) calculate mean and median on the price variable of the diamonds dataset# create a histogram and look at the distribution 
 

# 2) Does the curve of the depth variable of the same dataset have the same trend?


# 3) Create a correlation matrix of the numeric variables of the first 100 cases of the diamonds dataset

# 4) Create a correlation matrix of the dataset trees already present on R resources, # using the corrplot package, checking the documentation of the corrplot() function methods # and exploring the different methods 

# 5) Perform a basic exploratory analysis on the mpg dataset, # already present on the resources of R


# 6) Calculate the mean of the variables mark1 and mark2 of the df1.csv dataset located in the resource folder

# 7) Load the df2.csv dataset, count the missing data and create a chart to display it


# 8) Given the following dataset, impute the mean for the # variable var3 and the median for the variables var1 and var2 # instead of the missing valuesvar1 <- c(12, NA, 45, 57, 24, 48, NA)var2 <- c(NA, 37, 24, 61, NA, 19, NA)var3 <- c(71, NA, 45, 52, 70, 18, 34)df3 <- as.data.frame(cbind(var1, var2, var3))

# 9) load the dataset df4, calculate the outliers of the priceink variable and delete them

# 10) Upload df5 dataset and delete any duplicates in it
